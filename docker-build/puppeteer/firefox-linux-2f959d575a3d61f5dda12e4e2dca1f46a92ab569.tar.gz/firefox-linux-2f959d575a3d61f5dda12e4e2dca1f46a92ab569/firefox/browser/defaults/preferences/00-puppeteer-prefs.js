// Any comment. You must start the file with a single-line comment!
pref("general.config.filename", "puppeteer.cfg");
pref("general.config.obscure_value", 0);
